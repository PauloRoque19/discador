package br.com.netoware.apps.apphelloworld;

import android.annotation.SuppressLint;
import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteCursor;
import android.os.Build;
import android.os.Bundle;

import android.os.health.SystemHealthManager;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;

import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.AdapterViewAnimator;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;


public class UltimasChamadasActivity extends ListActivity  {


    int[] campos;
    Cursor ultimasChamadas = null;
    SimpleCursorAdapter adapter;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        String[] colunas = new String[]{"telefone", "data"};
        campos = new int[]{R.id.txtTelefone, R.id.txtDataHora};
        final ChamadaDAO chamadaDAO = new ChamadaDAO(this);
        ultimasChamadas = chamadaDAO.listAll();
        
        adapter = new SimpleCursorAdapter(this,R.layout.activity_ultimas_chamadas,ultimasChamadas,colunas,campos);

        setListAdapter(adapter);

    }


    public void removerChamadaPeloId(View v){

        ChamadaDAO dao = new ChamadaDAO(this);

        //TA PEGANDO O ID DA LISTA PROVAVELMENTE E O ID DO OBJETO CHAMADA QUE ESTA VINDO DO BANCO
       int i = getListView().getPositionForView(v);
       long chamada = getListAdapter().getItemId(i);


       try{
            dao.remove((int)chamada);
            this.onCreate(new Bundle());

       }catch (Exception e){
            Log.e("ERROU AO REMOVER",e.getMessage());
       }
        System.out.println("ID DO OBJETO: "+ chamada + "POSICAO DO BOTAO TALVEZ" + i);


        }



   /* @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);

        Object o = getListAdapter().getItem(position);
        String item = o.toString();

        Toast.makeText(this, item, Toast.LENGTH_SHORT).show();
    }*/
}
