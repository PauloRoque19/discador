package br.com.netoware.apps.apphelloworld;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class ChamadaDAO extends SQLiteOpenHelper {

    private static final String NOME_BANCO = "DB_DISCADOR";
    private static final int VERSAO = 1;
    private static final String TABELA = "chamadas";

    public ChamadaDAO(@Nullable Context context) {
        super(context, NOME_BANCO, null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String sql = "create table if not exists chamadas(_id integer primary key autoincrement,telefone text, data text)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean add(Chamada c){

        SQLiteDatabase db = getWritableDatabase();

        ContentValues dados = new ContentValues();
        dados.put("data",c.getData());
        dados.put("telefone",c.getTelefone());
        try {
            db.insert(TABELA,"",dados);
        } catch (Exception e){
            Log.e("ERRO","ERRO AO INSERIR CHAMADA NA TABELA: "+TABELA);
            return false;
        }

        return true;
    }

    public boolean update(Chamada c){

        SQLiteDatabase db = getWritableDatabase();

        ContentValues dados = new ContentValues();
        dados.put("data",c.getData());
        dados.put("telefone",c.getTelefone());

        try {
            db.update(TABELA,dados,"_id=?", new String[]{String.valueOf(c.getId())});
        } catch (Exception e){
            Log.e("ERRO","ERRO AO ATUALIZAR CHAMADA NA TABELA: "+TABELA);
            return false;
        }


        return true;
    }

    public boolean remove(int id){
        SQLiteDatabase db = getWritableDatabase();

        try {
            db.delete(TABELA,"_id = ?",new String[]{String.valueOf(id)});
        } catch (Exception e){
            Log.e("ERRO","ERRO AO DELETAR CHAMADA NA TABELA: "+TABELA);
            return false;
        }
        return true;
    }

    public Cursor listAll(){

        SQLiteDatabase db = getReadableDatabase();
        Cursor listChamadas = null;

        try {
            listChamadas = db.query(TABELA,new String[]{},"",new String[]{},"","","_id desc");


        } catch (Exception e){
            Log.e("ERRO","ERRO AO LISTAR CHAMADAS NA TABELA: "+TABELA);
            return listChamadas;
        }

        return listChamadas;

    }

    public void removerAll(){
        SQLiteDatabase db = getWritableDatabase();

        try {
            db.delete(TABELA,"",new String[]{});
        } catch (Exception e){
            Log.e("ERRO","ERRO AO DELETAR CHAMADA NA TABELA: "+TABELA);
        }

    }
}
