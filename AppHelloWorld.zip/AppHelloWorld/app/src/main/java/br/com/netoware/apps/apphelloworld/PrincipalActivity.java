package br.com.netoware.apps.apphelloworld;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class PrincipalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acitivty_principal);
    }


    public void abrirDiscador(View v) {

        Intent it = new Intent(this, MainActivity.class);

        startActivityForResult(it, 10);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 10) {

            if (resultCode == RESULT_OK) {
                Toast.makeText(this, data.getStringExtra("numeroDiscado"), Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Erro ao obter numero", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == 11) {

            if (resultCode == RESULT_CANCELED) {
                Toast.makeText(this, "Erro ao obter contado cadastrado", Toast.LENGTH_SHORT).show();
            }

        }

    }

    public void obterContato(View v) {

        Intent it = new Intent();

        startActivityForResult(it, 11);
    }
}