package br.com.netoware.apps.apphelloworld;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class MainActivity extends AppCompatActivity {

    private EditText edtNumeroTelefone;
    private Button btnNumero2;
    private String numeroDiscado = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtNumeroTelefone = findViewById(R.id.edtNumeroTelefone);
        btnNumero2 = findViewById(R.id.btnNumero2);
        //Intent it = getIntent();

        //Cliente cliente = (Cliente) it.getSerializableExtra("cliente1");

        //edtNumeroTelefone.setText(cliente.getTelefone());

    }


    public void apagarNumeros(View v) {

        edtNumeroTelefone.setText("");
    }

    public void discar(View v) throws ParseException {

        if (!edtNumeroTelefone.getText().toString().equals("")) {

            Uri uri = Uri.parse("tel:" + edtNumeroTelefone.getText().toString());
            Intent it = new Intent(Intent.ACTION_CALL, uri);
            numeroDiscado = edtNumeroTelefone.getText().toString();
            startActivity(it);

            Chamada chamada = new Chamada();
            chamada.setTelefone(numeroDiscado);
            SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy hh:mm");
            Calendar data = Calendar.getInstance();
            data.setTime(new Date());

            chamada.setData(data.getTime().toString());

            ChamadaDAO DAO = new ChamadaDAO(this);
            DAO.add(chamada);
        } else
            Toast.makeText(this, "Por favor informe o nº a ser discado.", Toast.LENGTH_SHORT).show();

    }

    @Override
    protected void onStop() {
        super.onStop();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }

    public void numeroDigitado(View v) throws IOException {

        ProgressDialog pd = null;

        switch (v.getId()) {

            case R.id.btnNumero1:
                edtNumeroTelefone.setText(edtNumeroTelefone.getText().toString() + "1");
                break;

            case R.id.btnNumero2:
                edtNumeroTelefone.setText(edtNumeroTelefone.getText().toString() + "2");
                break;

            case R.id.btnNumero3:
                edtNumeroTelefone.setText(edtNumeroTelefone.getText().toString() + "3");
                break;

            case R.id.btnNumero4:
                edtNumeroTelefone.setText(edtNumeroTelefone.getText().toString() + "4");
                break;

            case R.id.btnNumero5:
                edtNumeroTelefone.setText(edtNumeroTelefone.getText().toString() + "5");
                break;

            case R.id.btnNumero6:
                edtNumeroTelefone.setText(edtNumeroTelefone.getText().toString() + "6");
                break;

            case R.id.btnNumero7:
                edtNumeroTelefone.setText(edtNumeroTelefone.getText().toString() + "7");
                break;

            case R.id.btnNumero8:
                edtNumeroTelefone.setText(edtNumeroTelefone.getText().toString() + "8");
                break;

            case R.id.btnNumero9:
                edtNumeroTelefone.setText(edtNumeroTelefone.getText().toString() + "9");
                break;

            case R.id.btnZero:
                edtNumeroTelefone.setText(edtNumeroTelefone.getText().toString() + "0");
                break;

            case R.id.btnAsterisco:
                edtNumeroTelefone.setText(edtNumeroTelefone.getText().toString() + "*");
                break;

            case R.id.btnJogoDaVelha:

                edtNumeroTelefone.setText(edtNumeroTelefone.getText().toString() + "#");
                break;

            default:
                break;
        }

    }

}
